QUICKCHAT PART 3 - IMPLEMENTATION GUIDE

This is a clean Maven/NetBeans project based on the Chattingapp.zip source files. It preserves the existing Login validation and extends the messaging application for Part 3.

OPEN IN NETBEANS
1. Keep your original Chattingapp project and ZIP as a backup.
2. Extract QuickChat_Part3.zip to a normal folder (do not open the ZIP directly).
3. In NetBeans choose File > Open Project and select the extracted QuickChat_Part3 folder.
4. Wait for Maven dependencies to load. JUnit 5 is declared in pom.xml and requires internet access the first time if it is not cached.
5. Expand Source Packages > com.mycompany.chattingapp. The four Java files are Chattingapp.java, Login.java, Message.java and QuickChatApp.java, plus MessageManager.java.
6. Expand Test Packages and open Part3MessageManagerTest.java.
7. Right-click the project > Test. All Part 3 tests should pass.
8. Run Chattingapp.java to test registration/login and then the QuickChat menu. You can also run QuickChatApp.java directly to test messaging without the login screen.

MENU
1 sends a message; choose 1 (send), 2 (disregard), or 3 (store).
2 displays sent messages in the current run.
3 opens the Stored Messages submenu with all six assignment functions.
4 quits.
The five assignment sample records are represented in the test plan and can be loaded through MessageManager.populateTestData() when demonstrating the data arrays. The main menu remains at the required four options.

ARRAYS
MessageManager maintains sentMessages, disregardedMessages, storedMessages, messageHashes and messageIDs as ArrayLists. Records are added through the message action workflow; storedMessages is loaded from messages.json when MessageManager starts.

JSON
messages.json is created in the application's working directory when a message is stored or sample data is loaded. It is a JSON array of objects with messageID, messageHash, sender, recipient and message fields.

IMPORTANT ASSIGNMENT DETAIL
The supplied brief's unit-test table calls the value 0838884567 a messageID for Test Message 4, while the test-data table labels 0838884567 as the Developer number. Those are different concepts. The implementation keeps a generated 10-character message ID and separately stores 0838884567 as sender/developer contact for Test Message 4. The search function searches the actual generated message ID.
